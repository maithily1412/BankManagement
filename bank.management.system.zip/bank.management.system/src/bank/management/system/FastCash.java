
package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FastCash extends JFrame implements ActionListener {
    JButton hundred, twoHundred, fiveHundred, thousand, twoThousand, fiveThousand, backButton;
    String pin;

    FastCash(String pin) {
        this.pin = pin;

        setTitle("Fast Cash");
        setLayout(null);

        JLabel label = new JLabel("Select Withdrawal Amount:");
        label.setBounds(100, 100, 200, 30);
        add(label);

        hundred = createButton("100", 100, 150);
        twoHundred = createButton("200", 200, 150);
        fiveHundred = createButton("500", 300, 150);
        thousand = createButton("1000", 100, 200);
        twoThousand = createButton("2000", 200, 200);
        fiveThousand = createButton("5000", 300, 200);
        backButton = createButton("Back", 200, 300);

        add(hundred);
        add(twoHundred);
        add(fiveHundred);
        add(thousand);
        add(twoThousand);
        add(fiveThousand);
        add(backButton);

        setSize(500, 500);
        setLocation(500, 200);
        setVisible(true);
    }

    private JButton createButton(String text, int x, int y) {
        JButton button = new JButton(text);
        button.setBounds(x, y, 80, 30);
        button.addActionListener(this);
        return button;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton source = (JButton) e.getSource();
        if (source == backButton) {
            new MainClass(pin);
            setVisible(false);
        } else {
            // Add logic to handle fast cash withdrawal
            String amount = source.getText();
            JOptionPane.showMessageDialog(null, "Amount " + amount + " Withdrawn Successfully");
        }
    }
}

