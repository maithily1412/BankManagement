package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PinChange extends JFrame implements ActionListener {
    JPasswordField newPinField, confirmPinField;
    JButton changeButton, backButton;
    String pin;

    PinChange(String pin) {
        this.pin = pin;

        setTitle("Pin Change");
        setLayout(null);

        JLabel newPinLabel = new JLabel("Enter New PIN:");
        newPinLabel.setBounds(100, 100, 200, 30);
        add(newPinLabel);

        newPinField = new JPasswordField();
        newPinField.setBounds(250, 100, 150, 30);
        add(newPinField);

        JLabel confirmPinLabel = new JLabel("Confirm New PIN:");
        confirmPinLabel.setBounds(100, 150, 200, 30);
        add(confirmPinLabel);

        confirmPinField = new JPasswordField();
        confirmPinField.setBounds(250, 150, 150, 30);
        add(confirmPinField);

        changeButton = new JButton("Change");
        changeButton.setBounds(100, 200, 100, 30);
        changeButton.addActionListener(this);
        add(changeButton);

        backButton = new JButton("Back");
        backButton.setBounds(250, 200, 100, 30);
        backButton.addActionListener(this);
        add(backButton);

        setSize(500, 400);
        setLocation(500, 200);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == changeButton) {
            String newPin = new String(newPinField.getPassword());
            String confirmPin = new String(confirmPinField.getPassword());
            if (newPin.equals(confirmPin)) {
                // Add logic to change PIN
                JOptionPane.showMessageDialog(null, "PIN Changed Successfully");
            } else {
                JOptionPane.showMessageDialog(null, "PINs do not match");
            }
        } else if (e.getSource() == backButton) {
            new MainClass(pin);
            setVisible(false);
        }
    }
}

