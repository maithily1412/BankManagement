package bank.management.system;

import javax.swing.*;
import java.awt.*;

public class MiniStatement extends JFrame {
    String pin;

    MiniStatement(String pin) {
        this.pin = pin;

        setTitle("Mini Statement");
        setLayout(null);

        JLabel label = new JLabel("Mini Statement:");
        label.setBounds(100, 100, 200, 30);
        add(label);

        // Add logic to fetch and display mini statement
        JTextArea statementArea = new JTextArea("Transaction history here...");
        statementArea.setBounds(100, 150, 300, 200);
        add(statementArea);

        JButton backButton = new JButton("Back");

    }
}
