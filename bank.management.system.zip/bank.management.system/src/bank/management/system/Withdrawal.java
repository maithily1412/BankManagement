package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Withdrawal extends JFrame implements ActionListener {
    JTextField amountField;
    JButton withdrawButton, backButton;
    String pin;

    Withdrawal(String pin) {
        this.pin = pin;

        setTitle("Withdrawal");
        setLayout(null);

        JLabel label = new JLabel("Enter amount to withdraw:");
        label.setBounds(100, 100, 200, 30);
        add(label);

        amountField = new JTextField();
        amountField.setBounds(100, 140, 200, 30);
        add(amountField);

        withdrawButton = new JButton("Withdraw");
        withdrawButton.setBounds(100, 200, 100, 30);
        withdrawButton.addActionListener(this);
        add(withdrawButton);

        backButton = new JButton("Back");
        backButton.setBounds(220, 200, 100, 30);
        backButton.addActionListener(this);
        add(backButton);

        setSize(400, 400);
        setLocation(500, 200);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == withdrawButton) {
            String amount = amountField.getText();
            // Add logic to withdraw the amount
            JOptionPane.showMessageDialog(null, "Amount Withdrawn Successfully");
        } else if (e.getSource() == backButton) {
            new MainClass(pin);
            setVisible(false);
        }
    }
}
