

package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainClass extends JFrame implements ActionListener {
    JButton depositButton, withdrawButton, fastCashButton, miniStatementButton, pinChangeButton, balanceEnquiryButton, exitButton;
    String pin;

    public MainClass(String pin) {
        this.pin = pin;

        // Load the ATM image
        ImageIcon imageIcon = new ImageIcon(getClass().getClassLoader().getResource("icon/atm2.png"));
        Image image = imageIcon.getImage().getScaledInstance(1550, 830, Image.SCALE_DEFAULT);
        ImageIcon scaledIcon = new ImageIcon(image);
        JLabel backgroundLabel = new JLabel(scaledIcon);
        backgroundLabel.setBounds(0, 0, 1550, 830);
        add(backgroundLabel);

        // Transaction label
        JLabel transactionLabel = new JLabel("Please Select Your Transaction");
        transactionLabel.setBounds(430, 180, 700, 35);
        transactionLabel.setForeground(Color.WHITE);
        transactionLabel.setFont(new Font("System", Font.BOLD, 28));
        backgroundLabel.add(transactionLabel);

        // Initialize buttons
        depositButton = createButton("DEPOSIT", 410, 274);
        withdrawButton = createButton("CASH WITHDRAWAL", 700, 274);
        fastCashButton = createButton("FAST CASH", 410, 318);
        miniStatementButton = createButton("MINI STATEMENT", 700, 318);
        pinChangeButton = createButton("PIN CHANGE", 410, 362);
        balanceEnquiryButton = createButton("BALANCE ENQUIRY", 700, 362);
        exitButton = createButton("EXIT", 700, 406);

        // Add buttons to the background label
        backgroundLabel.add(depositButton);
        backgroundLabel.add(withdrawButton);
        backgroundLabel.add(fastCashButton);
        backgroundLabel.add(miniStatementButton);
        backgroundLabel.add(pinChangeButton);
        backgroundLabel.add(balanceEnquiryButton);
        backgroundLabel.add(exitButton);

        // Frame settings
        setLayout(null);
        setSize(1550, 1080);
        setLocation(0, 0);
        setVisible(true);
    }

    private JButton createButton(String text, int x, int y) {
        JButton button = new JButton(text);
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(65, 125, 128));
        button.setBounds(x, y, 150, 35);
        button.addActionListener(this);
        return button;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == depositButton) {
            new Deposit(pin);
            setVisible(false);
        } else if (e.getSource() == exitButton) {
            System.exit(0);
        } else if (e.getSource() == withdrawButton) {
            new Withdrawal(pin);
            setVisible(false);
        } else if (e.getSource() == balanceEnquiryButton) {
            new BalanceEnquiry(pin);
            setVisible(false);
        } else if (e.getSource() == fastCashButton) {
            new FastCash(pin);
            setVisible(false);
        } else if (e.getSource() == pinChangeButton) {
            new PinChange(pin);
            setVisible(false);
        } else if (e.getSource() == miniStatementButton) {
            new MiniStatement(pin);
        }
    }

    public static void main(String[] args) {
        new MainClass("");
    }
}
