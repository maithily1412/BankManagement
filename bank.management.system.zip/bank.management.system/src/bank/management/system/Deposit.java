package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Deposit extends JFrame implements ActionListener {
    JTextField amountField;
    JButton depositButton, backButton;
    String pin;

    Deposit(String pin) {
        this.pin = pin;

        setTitle("Deposit");
        setLayout(null);

        JLabel label = new JLabel("Enter amount to deposit:");
        label.setBounds(100, 100, 200, 30);
        add(label);

        amountField = new JTextField();
        amountField.setBounds(100, 140, 200, 30);
        add(amountField);

        depositButton = new JButton("Deposit");
        depositButton.setBounds(100, 200, 100, 30);
        depositButton.addActionListener(this);
        add(depositButton);

        backButton = new JButton("Back");
        backButton.setBounds(220, 200, 100, 30);
        backButton.addActionListener(this);
        add(backButton);

        setSize(400, 400);
        setLocation(500, 200);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == depositButton) {
            String amount = amountField.getText();
            // Add logic to deposit the amount
            JOptionPane.showMessageDialog(null, "Amount Deposited Successfully");
        } else if (e.getSource() == backButton) {
            new MainClass(pin);
            setVisible(false);
        }
    }
}

