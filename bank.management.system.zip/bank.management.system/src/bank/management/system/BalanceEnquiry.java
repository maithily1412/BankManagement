package bank.management.system;

import javax.swing.*;
import java.awt.*;

public class BalanceEnquiry extends JFrame {
    String pin;

    BalanceEnquiry(String pin) {
        this.pin = pin;

        setTitle("Balance Enquiry");
        setLayout(null);

        JLabel label = new JLabel("Your balance is: ");
        label.setBounds(100, 100, 200, 30);
        add(label);

        // Add logic to fetch and display balance
        JLabel balanceLabel = new JLabel("1000");  // Placeholder balance
        balanceLabel.setBounds(200, 100, 200, 30);
        add(balanceLabel);

        JButton backButton = new JButton("Back");
        backButton.setBounds(150, 200, 100, 30);
        backButton.addActionListener(e -> {
            new MainClass(pin);
            setVisible(false);
        });
        add(backButton);

        setSize(400, 400);
        setLocation(500, 200);
        setVisible(true);
    }
}


